// app/api/signup-applications/route.ts
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null);

    if (!body) {
      return NextResponse.json(
        { ok: false, error: "Invalid JSON body" },
        { status: 400 }
      );
    }

    const type = body.type as "store" | "therapist" | "user";
    const name = (body.name ?? "").toString().trim();
    const contact = body.contact ?? null;
    const payload = body.payload ?? null;
    const applicant_user_id = (body.applicant_user_id ?? "").toString();

    if (!type || !name || !applicant_user_id) {
      return NextResponse.json(
        { ok: false, error: "missing required fields", received: { type, name, applicant_user_id: !!applicant_user_id } },
        { status: 400 }
      );
    }

    // ★ service role なので RLS 無視で insert される
    const { data, error } = await supabaseAdmin
      .from("signup_applications")
      .insert({
        applicant_user_id,
        type,
        status: "pending",
        name,
        contact,
        payload,
      })
      .select("*")
      .single();

    if (error) {
      return NextResponse.json(
        {
          ok: false,
          error: error.message,
          code: error.code,
          details: error.details,
          hint: error.hint,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({ ok: true, data });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message ?? "Unknown error" },
      { status: 500 }
    );
  }
}